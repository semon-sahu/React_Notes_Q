import React from 'react'
import myimage from './assets/react.svg'

const Product = () => {
    let cards = [
      {
        id: 1,
        name: "Laptop",
        price: 12000,
        pimg: myimage,
      },
      {
        id: 2,
        name: "Mobile",
        price: 4000,
        pimg: myimage,
      },
    ];
  return (
    <div>
      <h1>Cart item - 0</h1>
      {
        cards.map((e)=>{
            return<>
            <div style={{border:"2px solid black"}}> 
                <img src={e.pimg} alt="" />
                <h2>Product name {e.product}</h2>
                <h3>Price {e.price}</h3>
                <button>add to cart</button>
            </div>
            </>

        })
      }
    </div>
  )
}

export default Product
