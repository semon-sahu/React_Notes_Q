import { createSlice, createSlice } from '@reduxjs/toolkit'



let createSlice = createSlice({
    name:"cart",
    initialState :{
        cartitems:[]
    },
    reducers:{
        additem:(state,action)=>{
            state.cartitems.push(action.payload)
        },
        clearcart : (state)=>{
            state.cartitems.length = 0
        }
    }
})
export default createSlice.reducers
export const {additem,clearcart}=createSlice.action


